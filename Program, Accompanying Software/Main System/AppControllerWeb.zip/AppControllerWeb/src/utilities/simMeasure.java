package utilities;

import java.math.BigDecimal;

public class simMeasure {
	private double[][] matrix1, matrix2;
	private int limit;
	public double[][] getMatrix1() {
		return matrix1;
	}
	public void setMatrix1(double[][] matrix1) {
		this.matrix1 = matrix1;
	}
	public double[][] getMatrix2() {
		return matrix2;
	}
	public void setMatrix2(double[][] matrix2) {
		this.matrix2 = matrix2;
	}
	public int getLimit() {
		return limit;
	}
	public void setLimit(int limit) {
		this.limit = limit;
	}
	public double measure() {
		BigDecimal frob = new BigDecimal(0.0);
		BigDecimal norm1 = new BigDecimal(0.0);
		BigDecimal norm2 = new BigDecimal(0.0);
		for(int i = 0; i < matrix1.length; i++) {
			for(int j = 0; j < limit; j++) {
				frob = frob.add(new BigDecimal(matrix1[i][j]).multiply(new BigDecimal(matrix2[i][j])));
				norm1 = norm1.add(new BigDecimal(matrix1[i][j]).multiply(new BigDecimal(matrix1[i][j])));
				norm2 = norm2.add(new BigDecimal(matrix2[i][j]).multiply(new BigDecimal(matrix2[i][j])));
			}
		}
		norm1 = new BigDecimal(Math.sqrt(norm1.doubleValue()));
		norm1 = norm1.setScale(15,BigDecimal.ROUND_UP);
		norm2 = new BigDecimal(Math.sqrt(norm2.doubleValue()));
		norm2 = norm2.setScale(15,BigDecimal.ROUND_UP);
		frob = frob.divide(norm1.multiply(norm2),15,BigDecimal.ROUND_UP);
		return frob.doubleValue();
	}
	// test it one more time
	// changes: made int to double
	public static void main(String args[]) {
		simMeasure sim = new simMeasure();
		double m1[][] = {{2,23,0,0,100},{100,100,2,100,100}};
		double m2[][] = {{100,1,0,0,100},{100,100,4,100,100}};
		sim.setMatrix1(m1);
		sim.setMatrix2(m2);
		sim.setLimit(m2[0].length);
		System.out.println(sim.measure());
	}
}
