package utilities;

import java.sql.*;

public class DBConUtility {
	public static Connection getConnection() {

		Connection connection = null;

		try {
			/*
			Class.forName(context.getInitParameter("jdbcDriver"));

			connection = DriverManager.getConnection(context.getInitParameter("jdbcURL"),
					context.getInitParameter("dbUserName"), context.getInitParameter("dbPassword"));

			System.out.println((connection != null) ? "successful connection" : "unable to connect to db server");
			*/
			
			String driver = "com.mysql.jdbc.Driver";
			String url = "jdbc:mysql://localhost:3306/conceptdatabase";
			String username ="root";
			String password="";
			Class.forName(driver);
			connection = DriverManager.getConnection(url, username, password);
		} catch (ClassNotFoundException cfne) {
			cfne.printStackTrace();
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		}

		return connection;
	}
}
