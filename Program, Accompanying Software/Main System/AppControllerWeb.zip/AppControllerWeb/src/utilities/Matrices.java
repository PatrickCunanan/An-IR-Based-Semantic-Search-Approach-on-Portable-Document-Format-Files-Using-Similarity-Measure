package utilities;

public class Matrices implements Comparable<Matrices>{
	private double[][] matrix1;
	private double[][] matrix2;
	private double score;
	private int index;
	
	public double getScore() {
		return score;
	}
	public void setScore(double score) {
		this.score = score;
	}
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}
	public double[][] getMatrix1() {
		return matrix1;
	}
	public void setMatrix1(double[][] matrix1) {
		this.matrix1 = matrix1;
	}
	public double[][] getMatrix2() {
		return matrix2;
	}
	public void setMatrix2(double[][] matrix2) {
		this.matrix2 = matrix2;
	}
	@Override
	public int compareTo(Matrices arg0) {
		if(score < arg0.score) {
			return -1;
		}
		else if(score > arg0.score) {
			return 1;
		}
		else {
			return 0;
		}
	}
	
}
