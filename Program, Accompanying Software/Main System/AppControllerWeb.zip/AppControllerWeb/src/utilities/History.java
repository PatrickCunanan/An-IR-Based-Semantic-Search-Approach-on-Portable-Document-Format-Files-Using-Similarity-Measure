package utilities;

import java.util.List;

public class History {
	private List<String> resultSet;
	private double[][] matrix;
	private String query;
	public List<String> getResultSet() {
		return resultSet;
	}
	public void setResultSet(List<String> resultSet) {
		this.resultSet = resultSet;
	}
	public double[][] getMatrix() {
		return matrix;
	}
	public void setMatrix(double[][] matrix) {
		this.matrix = matrix;
	}
	public String getQuery() {
		return query;
	}
	public void setQuery(String query) {
		this.query = query;
	}

}
