package controller;

import java.io.IOException;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.store.FSDirectory;

import model.CRUD;
import model.Processor;
import model.Refinement;
import model.ResultHistory;
import model.SearchModule;
import model.luceneSearch;
import utilities.DBConUtility;
import utilities.Reader;
import utilities.Stemmer;

public class AppController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private double[][][] model;
	private double[][] matrix;
	private ArrayList<String> documents;
	private HashMap<String, Integer> terms;
	private HashSet<String> stopWords;
	private String modelPath, matrixPath, docuPath, conceptSpaceIPath, termPath, wordNetPath, stopWordPath;
	private IndexReader reader;
	private IndexSearcher searcher;
	private Connection con;
    public void init(ServletConfig config)throws ServletException{
    	super.init(config);
    	modelPath = config.getInitParameter("tensorPath");
    	matrixPath = config.getInitParameter("matrixPath");
    	docuPath = config.getInitParameter("docuPath");
    	conceptSpaceIPath = config.getInitParameter("csIPath");
    	termPath = config.getInitParameter("termPath");
    	wordNetPath = config.getInitParameter("wordNetPath");
    	stopWordPath = config.getInitParameter("stopPath");
    	terms = Reader.readTerms(termPath);
    	model  = Reader.readTensor(modelPath);
    	matrix = Reader.readMatrix(matrixPath);
    	documents = Reader.readDocuPath(docuPath);
    	stopWords = Reader.readStopWords(stopWordPath);
    	Stemmer.initialize(wordNetPath);
    	con = DBConUtility.getConnection();
    	
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		double before = System.nanoTime();
		System.out.println("Actual running time: "+before);
		String query = request.getParameter("query");
		double alpha = Double.parseDouble(request.getParameter("alpha"));
		
		System.out.println("Preprocessing of the query...");
		Processor p = new Processor();
		p.setStopWords(stopWords);
		p.setQuery(query);
		String[] tokens = p.processIt();
		System.out.print("\t\tProcessed query: ");
		for(String s: tokens) {
			System.out.print(s+"  ");
		}
		System.out.println();
		
		System.out.println("User query concept Space construction......");
		reader = DirectoryReader.open(FSDirectory.open(Paths.get(conceptSpaceIPath))); 
		searcher = new IndexSearcher(reader);
		luceneSearch ls = new luceneSearch();
		ls.setSearcher(searcher);
		ls.setNumDocs(100);
		try {
			ls.search(query);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		for(String s: ls.getResults()) {
			System.out.println("\t\t"+s);
		}
		
		System.out.println("Refinement of third tensor model and super matrix...");
		int size =  ls.getResults().size();
		Refinement refiner  = new Refinement();
		refiner.setMatrix(matrix);
		refiner.setTensor(model);
		refiner.setSize(size);
		refiner.refine();
		int limit = refiner.getLimit();
		System.out.println("\t\tlimit size: "+size);
		
		System.out.println("User query matrix construction.....");
		SearchModule searcher = new SearchModule();
		searcher.setLimit(size);
		searcher.setDocPath(documents);
		searcher.setQuery(tokens);
		searcher.setSuperMatrix(matrix);
		searcher.setTensorRefined(model);
		searcher.setTerms(terms);
		searcher.buildQuerySuperMatrix();
		double[][] queryMatrix = searcher.getQuerySuperMatrix(); 
		System.out.println("Result set search.....");
		ResultHistory pool = new ResultHistory();
		pool.setAlpha(alpha);
		pool.setMatrix(queryMatrix);
		pool.search();
		System.out.println("\t\tmatch: "+pool.isMatch());
		if(pool.isMatch()) {
			System.out.println("\t\tRetrieved documents: ");
			request.setAttribute("documents", pool.getResultSet());
		}
		else {
			System.out.println("Searching documents.....");
			searcher.search();
			System.out.println("\t\tResult set:");
			List<String> results = searcher.getResults();
			try {
				CRUD.insertToDB(con, results, queryMatrix, query);
			}
			catch(SQLException e) {
				e.printStackTrace();
			}
			request.setAttribute("documents", results);
		}
		double after = System.nanoTime();
		after = (after - before) / 1000000000.0;
		System.out.println("Time elapsed:\t\t"+after);
		request.getRequestDispatcher("searchResults.jsp").forward(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
