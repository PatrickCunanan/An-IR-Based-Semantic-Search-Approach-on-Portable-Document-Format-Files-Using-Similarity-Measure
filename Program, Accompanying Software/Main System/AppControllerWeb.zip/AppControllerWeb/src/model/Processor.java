package model;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import utilities.Remover;
import utilities.Stemmer;

public class Processor {
	private String query;
	private HashSet<String> stopWords;
	
	public HashSet<String> getStopWords() {
		return stopWords;
	}

	public void setStopWords(HashSet<String> stopWords) {
		this.stopWords = stopWords;
	}

	public String getQuery() {
		return query;
	}

	public void setQuery(String query) {
		this.query = query;
	}
	
	public String[] processIt() {
		// removeit
		query = Remover.removeSymbols(query);
		// stem it
		query = Stemmer.stemIt(query);
		// tokenize it
		String[] tokens = query.split(" ");
		List<String> refinedTokens = new ArrayList<String>();
		for(String a: tokens) {
			if(stopWords.contains(a)) {
				//skip
			}
			else {
				refinedTokens.add(a);
			}
		}
		return refinedTokens.toArray(new String[0]);
	}
}
