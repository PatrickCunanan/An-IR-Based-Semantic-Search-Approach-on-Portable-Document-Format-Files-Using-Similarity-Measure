package model;

import java.util.ArrayList;
import java.util.HashMap;
import utilities.*;

public class SearchModule {
	private HashMap<String, Integer> terms;
	private ArrayList<String> docPath, results;
	private double[][][] tensorRefined;
	private double[][] superMatrix, querySuperMatrix;
	private String[] query;
	private int limit;
	
	public int getLimit() {
		return limit;
	}

	public void setLimit(int limit) {
		this.limit = limit;
	}

	public SearchModule() {
		results = new ArrayList<String>();
	}

	public ArrayList<String> getResults() {
		return results;
	}

	public double[][] getQuerySuperMatrix() {
		return querySuperMatrix;
	}

	public void setTerms(HashMap<String, Integer> terms) {
		this.terms = terms;
	}

	public void setDocPath(ArrayList<String> docPath) {
		this.docPath = docPath;
	}

	public void setTensorRefined(double[][][] tensorRefined) {
		this.tensorRefined = tensorRefined;
	}

	public void setSuperMatrix(double[][] superMatrix) {
		this.superMatrix = superMatrix;
	}

	public void setQuery(String[] query) {
		this.query = query;
	}

	public void search() {
		ArrayList<Double> similarityList = new ArrayList<Double>();
		for (int i = 0; i < tensorRefined.length; i++) {
			double[][] matrix = tensorRefined[i];
			simMeasure sim = new simMeasure();
			sim.setMatrix1(matrix);
			sim.setMatrix2(querySuperMatrix);
			sim.setLimit(limit);
			double similarity = sim.measure();
			//System.out.println(similarity);
			if (!(similarity > 0)) {
				continue;
			} else {
				// insertion sort
				if (similarityList.isEmpty()) {
					similarityList.add(similarity);
					results.add(docPath.get(i));
				} else if (similarityList.get(similarityList.size() - 1) > similarity) {
					similarityList.add(similarity);
					results.add(docPath.get(i));
				} else {
					for (int j = 0; j < similarityList.size(); j++) {
						if (similarityList.get(j) <= similarity) {
							similarityList.add(j, similarity);
							results.add(j, docPath.get(i));
							break;
						}
					}
				}
			}
		}
	}

	public void buildQuerySuperMatrix() {
		int numTerms = terms.size();
		int numConcepts = limit;
		querySuperMatrix = new double[numTerms][numConcepts];
		for (int i = 0; i < numTerms; i++) {
			for (int j = 0; j < numConcepts; j++) {
				querySuperMatrix[i][j] = 0;
			}
		}
		for (int i = 0; i < query.length; i++) {
			int queryIndex = (terms.get(query[i]) != null) ? terms.get(query[i]) : -1;
			if (queryIndex == -1) {
				continue;
			} else {
				for (int j = 0; j < numConcepts; j++) {
					querySuperMatrix[queryIndex][j] = superMatrix[queryIndex][j];
				}
			}
		}
	}
	/*
	 * public void search() { double[][] simMeasureMatrix = new
	 * double[numDocs][numDocs]; int[] similarityFreq = new int[numDocs];
	 * ArrayList<Integer> similarityFreqList = new ArrayList<Integer>(); for
	 * (int i = 0; i < numDocs; i++) { double[][] matrix1 = tensorRefined[i];
	 * for (int j = 0; j < numDocs; j++) { if (j < i) { simMeasureMatrix[i][j] =
	 * simMeasureMatrix[j][i]; } else { double[][] matrix2 = tensorRefined[j];
	 * simMeasure sim = new simMeasure(); sim.setMatrix1(matrix1);
	 * sim.setMatrix2(matrix2); simMeasureMatrix[i][j] = sim.measure(); }
	 * 
	 * if (simMeasureMatrix[i][j] >= alpha) { similarityFreq[i]++; } }
	 * 
	 * if (similarityFreqList.isEmpty()) {
	 * similarityFreqList.add(similarityFreq[i]);
	 * results.add(conceptSpace.get(i).docPath); } else if
	 * (similarityFreqList.get(similarityFreqList.size() - 1) >
	 * similarityFreq[i]) { similarityFreqList.add(similarityFreq[i]);
	 * results.add(conceptSpace.get(i).docPath); } else { for (int j = 0; j <
	 * similarityFreqList.size(); j++) { if (similarityFreqList.get(j) <=
	 * similarityFreq[i]) { similarityFreqList.add(j, similarityFreq[i]);
	 * results.add(j, conceptSpace.get(i).docPath); break; } } } } }
	 */

	public static void main(String[] args) {
		ArrayList<String> docPath = new ArrayList<String>();
		HashMap<String, Integer> terms = new HashMap<String, Integer>();
		docPath.add("document1");
		docPath.add("document2");
		docPath.add("document3");
		docPath.add("document4");
		docPath.add("document5");
		terms.put("apple", 0);
		terms.put("banana", 1);
		double[][][] tensorRefined = { { { 1, 2, 3 }, { 4, 5, 6 } }, { { 1, 2, 3 }, { 13, 14, 15 } },
				{ { 1, 2, 3 }, { 22, 23, 24 } } };
		double[][] superMatrix = {{1,2,3},{13,14,15}};
		String[] query = {"apple", "banana"}; 
		SearchModule sm = new SearchModule();
		sm.setDocPath(docPath);
		sm.setTensorRefined(tensorRefined);
		sm.setQuery(query);
		sm.setSuperMatrix(superMatrix);
		sm.setTerms(terms);
		sm.buildQuerySuperMatrix();
		sm.search();
		for (int i = 0; i < sm.getQuerySuperMatrix().length; i++){
			for (int j = 0; j < sm.getQuerySuperMatrix()[i].length; j++){
				System.out.print(sm.getQuerySuperMatrix()[i][j]+" ");
			}
			System.out.println();;
		}
		for (int i = 0; i < sm.getResults().size(); i++) {
			System.out.println(sm.getResults().get(i));
		}

	}

}