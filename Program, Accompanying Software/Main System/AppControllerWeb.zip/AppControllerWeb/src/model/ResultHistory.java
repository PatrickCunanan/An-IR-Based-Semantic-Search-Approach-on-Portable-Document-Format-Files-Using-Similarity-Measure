package model;


import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import utilities.DBConUtility;
import utilities.History;
import utilities.Matrices;
import utilities.MergeSort;
import utilities.simMeasure;

public class ResultHistory {
	private double alpha;
	private Connection con;
	private double[][] matrix;
	private List<String> resultSet;
	private boolean match;
	public double getAlpha() {
		return alpha;
	}
	
	public double[][] getMatrix() {
		return matrix;
	}

	public void setMatrix(double[][] matrix) {
		this.matrix = matrix;
	}

	public List<String> getResultSet() {
		return resultSet;
	}

	public void setResultSet(List<String> resultSet) {
		this.resultSet = resultSet;
	}

	public boolean isMatch() {
		return match;
	}

	public void setMatch(boolean match) {
		this.match = match;
	}

	public void setAlpha(double alpha) {
		this.alpha = alpha;
	}
	public double[][] equalize(double[][] matrix, int size){
		double[][] newMatrix = new double[matrix.length][size];
		for(int i = 0; i < matrix.length; i++) {
			for(int j = 0; j < size; j++) {
				if(j < matrix[0].length) {
					newMatrix[i][j] = matrix[i][j];
				}
				else {
					newMatrix[i][j] = 0;
				}
			}
		}
		return newMatrix;
	}
	public ResultHistory() {
		try {
			con = DBConUtility.getConnection();
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	public void search() {
		
		History[] histories = null;
		try {
			histories = CRUD.getResult(con);
		}
		catch(SQLException e) {
			System.out.println(e.getMessage());
		}
		catch(IOException e) {
			System.out.println(e.getMessage());
		}
		catch(ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}
		finally{
			try{ if(con != null) con.close(); } catch(Exception e) {}
		}
		if(histories.length != 0) {	
			List<Matrices> matrices = new ArrayList<Matrices>();
			for(int i = 0; i < histories.length; i++) {
				Matrices mainMatrix = new Matrices();
				simMeasure calculator = new simMeasure();
				double [][] matrix2 = histories[i].getMatrix();
				// equalize
				if(matrix[0].length > matrix2[0].length) {
					matrix2 = equalize(matrix2, matrix[0].length);
				}
				else if(matrix[0].length < matrix2[0].length) {
					matrix = equalize(matrix, matrix2[0].length);
				}
				else {
					//skip
				}
				double score = 0;
				calculator.setMatrix1(matrix);
				calculator.setMatrix2(matrix2);
				calculator.setLimit(matrix[0].length);
				score = calculator.measure();
				System.out.println(score);
				mainMatrix.setMatrix1(matrix);
				mainMatrix.setMatrix2(matrix2);
				mainMatrix.setIndex(i);
				mainMatrix.setScore(score);;
				matrices.add(mainMatrix);
			}
			// mergesort
			MergeSort<Matrices> merger = new MergeSort<Matrices>();
			merger.setOrder(merger.DESCENDING);
			matrices = merger.mergesort(matrices);
		
			if(matrices.get(0).getScore() >= alpha) {
				match = true;
				resultSet = histories[matrices.get(0).getIndex()].getResultSet();
			}
			else {
				match = false;
				resultSet = null;
			}
		}
		else {
			match = false;
			resultSet = null;
		}
	}
}
