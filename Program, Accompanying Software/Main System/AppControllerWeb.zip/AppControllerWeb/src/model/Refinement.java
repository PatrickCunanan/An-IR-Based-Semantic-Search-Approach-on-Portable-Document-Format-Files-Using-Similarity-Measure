package model;

public class Refinement {
	private double[][][] tensor;
	private double[][] matrix;
	private int size;
	private int limit;
	
	public int getLimit() {
		return limit;
	}
	public void setLimit(int limit) {
		this.limit = limit;
	}
	public double[][][] getTensor() {
		return tensor;
	}
	public void setTensor(double[][][] tensor) {
		this.tensor = tensor;
	}
	public double[][] getMatrix() {
		return matrix;
	}
	public void setMatrix(double[][] matrix) {
		this.matrix = matrix;
	}
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	public void refine() {
		if(size >= tensor[0][0].length) {
			limit = tensor[0][0].length;
		}
		else {
			limit = size;
		}
	}
	
}
