package model;

import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import utilities.History;

public class CRUD {
	public static void main(String args[]) {
		double array[][] = new double[900000][1];
		for(int i = 0; i < array.length; i++) {
			for(int j = 0; j < array[0].length; j++) {
				array[i][j] = 9;
			}
		}
	}
	// convert the matrix to list para ma store sa db
	public static List<Double> toList(double[][] array) {
		List<Double> listHolder = new ArrayList<Double>();
		int arrayRowLength = array.length;
		int arrayColumnLength = array[0].length;

		for (int i = 0; i < arrayRowLength; i++) {
			for (int j = 0; j < arrayColumnLength; j++) {
				listHolder.add(array[i][j]);
			}
		}
		return listHolder;
	}

	// para mabalik to a double array yung list na inistore sa db
	public static double[][] toArray(List<Double> list, int row, int column) {
		double[][] arrayHolder = new double[row][column];
		int counter = 0;
		for (int i = 0; i < row; i++) {
			for (int j = 0; j < column; j++) {
				arrayHolder[i][j] = list.get(counter);
				counter++;
			}
		}
		return arrayHolder;
	}

	// pasok mo dito yung mga concept, matrix, at query para malagay sa database
	public static long insertToDB(Connection con, List<String> concepts, double[][] matrix, String query)
			throws SQLException {
		List<Object> object = new ArrayList<Object>();
		int row = matrix.length;
		int column = matrix[0].length;
		List<Double> matrixList = toList(matrix);
		object.add(query);
		object.add(concepts);
		object.add(matrixList);
		object.add(row);
		object.add(column);

		PreparedStatement pstmt = con.prepareStatement("insert into concepttable(object) values (?)",
				Statement.RETURN_GENERATED_KEYS);
		pstmt.setObject(1, object);
		pstmt.executeUpdate();
		ResultSet rs = pstmt.getGeneratedKeys();
		int serialid = -1;
		if (rs.next()) {
			serialid = rs.getInt(1);
		}
		rs.close();
		pstmt.close();
		return serialid;
	}

	public static History[] getResult(Connection con) throws SQLException, IOException, ClassNotFoundException {
		PreparedStatement pstmt = con.prepareStatement("select object from concepttable");
		ResultSet rs = pstmt.executeQuery();
		List<History> history = new ArrayList<History>();
		while (rs.next()) {
			byte[] buffer = rs.getBytes(1);
			ObjectInputStream objectIn = null;
			if (buffer != null) {
				objectIn = new ObjectInputStream(new ByteArrayInputStream(buffer));
			}

			Object object = objectIn.readObject();
			List<Object> objectHolder = (List<Object>) object;
			String queryHolder = (String) objectHolder.get(0);
			List<String> conceptHolder = (List<String>) objectHolder.get(1);
			List<Double> matrixListHolder = (List<Double>) objectHolder.get(2);
			int rowHolder = (Integer) objectHolder.get(3);
			int columnHolder = (Integer) objectHolder.get(4);
			double[][] matrixHolder = toArray(matrixListHolder, rowHolder, columnHolder);

			History result = new History();
			result.setQuery(queryHolder);
			result.setResultSet(conceptHolder);
			result.setMatrix(matrixHolder);

			history.add(result);

			//pang output lang
			/*System.out.println(result.getQuery());
			System.out.println(result.getConcepts());
			for (int i = 0; i < result.getMatrix().length; i++) {
				for (int j = 0; j < result.getMatrix()[0].length; j++) {
					System.out.print(result.getMatrix()[i][j] + " ");
				}
				System.out.println();
			}*/

		}
		rs.close();
		pstmt.close();

		History[] historyHolder = new History[history.size()];
		historyHolder = history.toArray(historyHolder);

		return historyHolder;
	}

	// pang delete ng record sa db
	public static void deleteFromDB(Connection con, long serialid) throws SQLException {
		PreparedStatement pstmt = con.prepareStatement("delete from concepttable where serialid = ?");
		pstmt.setLong(1, serialid);
		pstmt.executeQuery();
		pstmt.close();
	}

	// tester
	/*public static void main(String[] args) throws ClassNotFoundException, SQLException, IOException {
		Connection connection = null;
		String driver = "com.mysql.jdbc.Driver";
		String url = "jdbc:mysql://localhost:3306/conceptdatabase";
		String username = "root";
		String password = "";
		Class.forName(driver);
		connection = DriverManager.getConnection(url, username, password);

		String query = "Sample Query";

		List<String> concept = new ArrayList<String>();
		concept.add("Sample Concept 1");
		concept.add("Sample Concept 2");
		concept.add("Sample Concept 3");

		double[][] matrix = { { 1, 2, 3, 4 }, { 5, 6, 7, 8 } };

		insertToDB(connection,concept,matrix,query);
		getResult(connection);
	}
	*/

}
